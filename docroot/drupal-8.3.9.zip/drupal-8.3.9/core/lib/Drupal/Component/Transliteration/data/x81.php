<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'cheng', 'tiao', 'zhi', 'cui', 'mei', 'xie', 'cui', 'xie', 'mai', 'mai', 'ji', 'xie', 'nin', 'kuai', 'sa', 'zang',
  0x10 => 'qi', 'nao', 'mi', 'nong', 'luan', 'wan', 'bo', 'wen', 'wan', 'xiu', 'jiao', 'jing', 'you', 'heng', 'cuo', 'lie',
  0x20 => 'shan', 'ting', 'mei', 'chun', 'shen', 'qian', 'de', 'juan', 'cu', 'xiu', 'xin', 'tuo', 'pao', 'cheng', 'nei', 'pu',
  0x30 => 'dou', 'tuo', 'niao', 'nao', 'pi', 'gu', 'luo', 'li', 'lian', 'zhang', 'cui', 'jie', 'liang', 'shui', 'pi', 'biao',
  0x40 => 'lun', 'pian', 'lei', 'kui', 'chui', 'dan', 'tian', 'nei', 'jing', 'nai', 'la', 'ye', 'yan', 'ren', 'shen', 'chuo',
  0x50 => 'fu', 'fu', 'ju', 'fei', 'qiang', 'wan', 'dong', 'pi', 'guo', 'zong', 'ding', 'wo', 'mei', 'ni', 'zhuan', 'chi',
  0x60 => 'cou', 'luo', 'ou', 'di', 'an', 'xing', 'nao', 'shu', 'shuan', 'nan', 'yun', 'zhong', 'rou', 'e', 'sai', 'tu',
  0x70 => 'yao', 'jian', 'wei', 'jiao', 'yu', 'jia', 'duan', 'bi', 'chang', 'fu', 'xian', 'ni', 'mian', 'wa', 'teng', 'tui',
  0x80 => 'bang', 'qian', 'lu', 'wa', 'sou', 'tang', 'su', 'zhui', 'ge', 'yi', 'bo', 'liao', 'ji', 'pi', 'xie', 'gao',
  0x90 => 'lu', 'bin', 'ou', 'chang', 'lu', 'guo', 'pang', 'chuai', 'biao', 'jiang', 'fu', 'tang', 'mo', 'xi', 'zhuan', 'lu',
  0xA0 => 'jiao', 'ying', 'lu', 'zhi', 'xue', 'chun', 'lin', 'tong', 'peng', 'ni', 'chuai', 'liao', 'cui', 'gui', 'xiao', 'teng',
  0xB0 => 'fan', 'zhi', 'jiao', 'shan', 'hu', 'cui', 'run', 'xiang', 'sui', 'fen', 'ying', 'shan', 'zhua', 'dan', 'kuai', 'nong',
  0xC0 => 'tun', 'lian', 'bi', 'yong', 'jue', 'chu', 'yi', 'juan', 'la', 'lian', 'sao', 'tun', 'gu', 'qi', 'cui', 'bin',
  0xD0 => 'xun', 'nao', 'wo', 'zang', 'xian', 'biao', 'xing', 'kuan', 'la', 'yan', 'lu', 'huo', 'za', 'luo', 'qu', 'zang',
  0xE0 => 'luan', 'ni', 'za', 'chen', 'qian', 'wo', 'guang', 'zang', 'lin', 'guang', 'zi', 'jiao', 'nie', 'chou', 'ji', 'gao',
  0xF0 => 'chou', 'mian', 'nie', 'zhi', 'zhi', 'ge', 'jian', 'die', 'zhi', 'xiu', 'tai', 'zhen', 'jiu', 'xian', 'yu', 'cha',
];
